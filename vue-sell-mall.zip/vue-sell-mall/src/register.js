import {createAPI} from 'cube-ui'
import Vue from 'vue'
import headerDetail from 'components/header-detail/header-detail'
import shopCartList from 'components/shop-cart-list/Shop-cart-list'
import ShopCartSticky  from 'components/shop-cart-sticky/Shop-cart-sticky'
import Food from 'components/food/Food'

createAPI(Vue, headerDetail)
createAPI(Vue, shopCartList)
createAPI(Vue, ShopCartSticky)
createAPI(Vue, Food)